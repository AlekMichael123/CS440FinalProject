CS440 - Group 2 - Final Project - Own Design
Group members:
	* Alek Michael
	* Alex Worland
	* Vito Luong
	* Conner Gordon


Contained is both our actual project propsal, 3D Conway's Game of Life, 
along with a 2D implementation that was created as a frame of reference.

From here, head to 
*\CS440-Group2-FinalProject-OwnProject-3D.zip\CS440-Group2-FinalProject-OwnProject\fig2-10
to find the 3D program. 

3D CONTROLS:

		q
			Quits the program
		w/a/s/d
			Camera controls
		r/f
			Zoom in and out
		z/x
			Rotate horizontally
		p
			Start and pause game
		t
			Reset game to setting mode
		l
			Reset game with random seed

		In setting mode:
		Arrow keys
			Move cursor in x/y axes
		Shift + up/down
			move cursor in z axis
		Spacebar
			Select and unselect a cell for the initial seed
