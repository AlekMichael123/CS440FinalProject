CS440 - Group 2 - Final Project - Visualization Portion with Bezier Curves
Group members:
	* Alek Michael
	* Alex Worland
	* Vito Luong
	* Conner Gordon


Contained program reads 'data.txt' and visualizes it using bezier curves. 
It considers the last index of data as either '1' to be above the axis or '-1' to be below. 
Supports n 10-D data points. 

Current 'data.txt' is the cancer data.
Also contained the iris data 'irisdata.txt' formatted to be properly read. 